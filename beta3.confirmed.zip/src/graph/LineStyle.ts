/*
  fTelnet: An HTML5 WebSocket client
  Copyright (C) Rick Parrish, R&M Software

  This file is part of fTelnet.

  fTelnet is free software: you can redistribute it and/or modify
  it under the terms of the GNU Affero General Public License as
  published by the Free Software Foundation, either version 3 of the
  License, or any later version.

  fTelnet is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU Affero General Public License for more details.

  You should have received a copy of the GNU Affero General Public License
  along with fTelnet.  If not, see <http://www.gnu.org/licenses/>.
*/

/**
 * Line dash patterns for BGI line-drawing operations.
 *
 * Note: `Normal` and `Solid` are aliases (both = 0) — the original
 * declared both, matching the BGI convention where "normal" is
 * spelled differently in different documentation. Strict TypeScript
 * accepts duplicate enum values, so this works as-is.
 */
export enum LineStyle {
  Normal = 0,
  Solid = 0,
  Dotted = 1,
  Center = 2,
  Dashed = 3,
  /** User-supplied 16-bit pattern via `Graph.SetLineStyle` */
  User = 4,
}
