/*
  fTelnet: An HTML5 WebSocket client
  Copyright (C) Rick Parrish, R&M Software

  This file is part of fTelnet.

  fTelnet is free software: you can redistribute it and/or modify
  it under the terms of the GNU Affero General Public License as
  published by the Free Software Foundation, either version 3 of the
  License, or any later version.

  fTelnet is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY, without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU Affero General Public License for more details.

  You should have received a copy of the GNU Affero General Public License
  along with fTelnet.  If not, see <http://www.gnu.org/licenses/>.
*/

/**
 * Content alignment options for text inside `CrtControl` subclasses.
 *
 * The "compound" values (BottomLeft, MiddleCenter, etc.) are used by
 * `CrtPanel` to position window titles around the border. The simple
 * Left/Center/Right values are used by `CrtLabel` for single-line
 * text alignment within the control area.
 */
export enum ContentAlignment {
  BottomLeft = 0,
  BottomCenter = 1,
  BottomRight = 2,
  MiddleLeft = 3,
  MiddleCenter = 4,
  MiddleRight = 5,
  TopLeft = 6,
  TopCenter = 7,
  TopRight = 8,
  Left = 9,
  Center = 10,
  Right = 11,
}
